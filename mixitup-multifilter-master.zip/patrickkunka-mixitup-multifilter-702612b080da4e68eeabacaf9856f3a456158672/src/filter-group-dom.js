/* global mixitup, h */

mixitup.FilterGroupDom = function() {
    this.el     = null;
    this.form   = null;

    h.seal(this);
};